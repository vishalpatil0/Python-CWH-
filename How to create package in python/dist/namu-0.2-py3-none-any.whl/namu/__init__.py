class namrata:
    def __init__(self):
        print("Constructor")

    def vishu(self):
        print("myself vishal patil")