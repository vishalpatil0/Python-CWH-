def vishu():
    print("myself vishal patil")