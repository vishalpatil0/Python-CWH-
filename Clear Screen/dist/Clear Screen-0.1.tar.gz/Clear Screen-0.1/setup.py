from setuptools import setup
setup(name="Clear Screen",
version="0.1",
description="This is code clear the terminal screen",
long_description = "Used for various platforms",
author="Vishal",
packages=['Clear'],
install_requires=[])